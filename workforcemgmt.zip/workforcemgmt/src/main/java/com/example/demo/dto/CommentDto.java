package com.example.demo.dto;

import java.time.Instant;

import lombok.Data;

@Data
public class CommentDto {
  private String author;
  private String text;
  private Instant timestamp;
}
