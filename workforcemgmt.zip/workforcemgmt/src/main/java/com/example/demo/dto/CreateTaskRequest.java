package com.example.demo.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class CreateTaskRequest {
  private String title;
  private String assigneeId;
  private LocalDate startDate;
  private LocalDate dueDate;
}
