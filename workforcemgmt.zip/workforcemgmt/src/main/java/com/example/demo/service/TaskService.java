package com.example.demo.service;


import org.springframework.stereotype.Service;

import com.example.demo.dto.CommentDto;
import com.example.demo.dto.CreateTaskRequest;
import com.example.demo.dto.TaskDto;
import com.example.demo.model.Staff;
import com.example.demo.model.Task;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();
    private final Map<String, Staff> staff = new HashMap<>();

    public TaskService() {
        Staff s = new Staff();
        s.setId("1");
        s.setName("Alice");
        staff.put(s.getId(), s);
    }

    public TaskDto createTask(CreateTaskRequest r) {
        // Implement task creation logic here
        return null; // placeholder
    }

    public TaskDto reassignTask(String taskId, String newAssigneeId) {
        // Implement reassign logic: cancel old task, assign new task, log activity
        return null; // placeholder
    }

    public List<TaskDto> fetchTasks(String staffId, LocalDate from, LocalDate to) {
        // Implement fetching tasks with smart logic, skip CANCELLED
        return Collections.emptyList(); // placeholder
    }

    public TaskDto changePriority(String taskId, Task.Priority p) {
        // Implement priority change + logging
        return null; // placeholder
    }

    public List<TaskDto> tasksByPriority(Task.Priority p) {
        // Filter tasks by priority
        return tasks.values().stream()
                .filter(task -> task.getPriority() == p && task.getStatus() != Task.Status.CANCELLED)
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public CommentDto addComment(String taskId, String author, String text) {
        // Add comment and log activity
        return null; // placeholder
    }

    public TaskDto getTaskDetail(String taskId) {
        // Return task details with comments and activity log
        return null; // placeholder
    }

    private TaskDto toDto(Task task) {
        // Mapping from Task to TaskDto (you should implement this or use MapStruct)
        return null; // placeholder
    }
}


