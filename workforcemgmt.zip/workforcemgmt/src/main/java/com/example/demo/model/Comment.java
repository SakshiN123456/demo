package com.example.demo.model;

import java.time.Instant;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class Comment {
  private String author;
  private String text;
  private Instant timestamp;
}
