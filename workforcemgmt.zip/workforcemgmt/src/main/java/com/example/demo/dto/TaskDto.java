package com.example.demo.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.Data;

@Data
public class TaskDto {
  public enum Status { ACTIVE, COMPLETED, CANCELLED }
  public enum Priority { HIGH, MEDIUM, LOW }

  private String id;
  private String title;
  private String assigneeId;
  private Status status;
  private Priority priority;
  private LocalDate startDate;
  private LocalDate dueDate;
  private List<CommentDto> comments;
  private List<String> activityLog;
}
