package com.example.demo.controller;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CommentDto;
import com.example.demo.dto.CreateTaskRequest;
import com.example.demo.dto.TaskDto;
import com.example.demo.model.Task;
import com.example.demo.service.TaskService;


@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService taskService;

    // Constructor injection for TaskService
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // Create a new task
    @PostMapping
    public ResponseEntity<TaskDto> createTask(@RequestBody CreateTaskRequest request) {
        TaskDto created = taskService.createTask(request);
        return ResponseEntity.ok(created);
    }

    // Reassign a task to a different staff member
    @PostMapping("/{taskId}/reassign/{newAssigneeId}")
    public ResponseEntity<TaskDto> reassignTask(
            @PathVariable String taskId,
            @PathVariable String newAssigneeId) {
        TaskDto reassigned = taskService.reassignTask(taskId, newAssigneeId);
        return ResponseEntity.ok(reassigned);
    }

    // Fetch tasks for a staff between date range (excluding CANCELLED tasks)
    @GetMapping
    public ResponseEntity<List<TaskDto>> fetchTasks(
            @RequestParam String staffId,
            @RequestParam LocalDate from,
            @RequestParam LocalDate to) {
        List<TaskDto> tasks = taskService.fetchTasks(staffId, from, to);
        return ResponseEntity.ok(tasks);
    }

    // Change priority of a task
    @PutMapping("/{taskId}/priority")
    public ResponseEntity<TaskDto> changePriority(
            @PathVariable String taskId,
            @RequestParam Task.Priority priority) {
        TaskDto updated = taskService.changePriority(taskId, priority);
        return ResponseEntity.ok(updated);
    }

    // Get tasks by priority
    @GetMapping("/priority/{priority}")
    public ResponseEntity<List<TaskDto>> getTasksByPriority(@PathVariable Task.Priority priority) {
        List<TaskDto> tasks = taskService.tasksByPriority(priority);
        return ResponseEntity.ok(tasks);
    }

    // Add a comment to a task
    @PostMapping("/{taskId}/comments")
    public ResponseEntity<CommentDto> addComment(
            @PathVariable String taskId,
            @RequestParam String author,
            @RequestParam String text) {
        CommentDto comment = taskService.addComment(taskId, author, text);
        return ResponseEntity.ok(comment);
    }

    // Get task details (including comments and activity log)
    @GetMapping("/{taskId}")
    public ResponseEntity<TaskDto> getTaskDetail(@PathVariable String taskId) {
        TaskDto task = taskService.getTaskDetail(taskId);
        return ResponseEntity.ok(task);
    }
}